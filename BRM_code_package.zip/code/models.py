"""Dual-encoder models (item-token Transformer or MLP) trained with JAX."""
import numpy as np, jax, jax.numpy as jnp, pickle, os
from functools import partial

D_MODEL, HEADS, LAYERS, FF, D_OUT = 64, 4, 2, 128, 64


def _init_tf(key, p, d=D_MODEL):
    ks = jax.random.split(key, 4 + 6 * LAYERS)
    s = lambda k, sh, sc: jax.random.normal(k, sh) * sc
    P = dict(Wv=s(ks[0], (p, d), 0.1), Bi=s(ks[1], (p, d), 0.1), lnf=(jnp.ones(d), jnp.zeros(d)),
             proj=s(ks[2], (d, D_OUT), d ** -0.5), layers=[])
    for l in range(LAYERS):
        k = ks[4 + 6 * l: 10 + 6 * l]
        P["layers"].append(dict(ln1=(jnp.ones(d), jnp.zeros(d)), qkv=s(k[0], (d, 3 * d), d ** -0.5), o=s(k[1], (d, d), d ** -0.5),
                                ln2=(jnp.ones(d), jnp.zeros(d)), w1=s(k[2], (d, FF), d ** -0.5), b1=jnp.zeros(FF),
                                w2=s(k[3], (FF, d), FF ** -0.5), b2=jnp.zeros(d)))
    return P


def _ln(x, gb):
    m = x.mean(-1, keepdims=True); v = ((x - m) ** 2).mean(-1, keepdims=True)
    return (x - m) / jnp.sqrt(v + 1e-5) * gb[0] + gb[1]


def tf_encode(P, X):
    h = X[..., None] * P["Wv"] + P["Bi"]                       # (n, p, d): item value x item embedding
    n, p, d = h.shape; dh = d // HEADS
    for L in P["layers"]:
        q, k, v = jnp.split(_ln(h, L["ln1"]) @ L["qkv"], 3, -1)
        q = q.reshape(n, p, HEADS, dh); k = k.reshape(n, p, HEADS, dh); v = v.reshape(n, p, HEADS, dh)
        a = jax.nn.softmax(jnp.einsum("nihd,njhd->nhij", q, k) / jnp.sqrt(dh), -1)
        h = h + jnp.einsum("nhij,njhd->nihd", a, v).reshape(n, p, d) @ L["o"]
        h = h + jax.nn.gelu(_ln(h, L["ln2"]) @ L["w1"] + L["b1"]) @ L["w2"] + L["b2"]
    pooled = _ln(h.mean(1), P["lnf"])
    return pooled @ P["proj"], pooled


def _init_mlp(key, p):
    k = jax.random.split(key, 3)
    return dict(w1=jax.random.normal(k[0], (p, 128)) * p ** -0.5, b1=jnp.zeros(128),
                w2=jax.random.normal(k[1], (128, D_MODEL)) * 128 ** -0.5, b2=jnp.zeros(D_MODEL),
                proj=jax.random.normal(k[2], (D_MODEL, D_OUT)) * D_MODEL ** -0.5)


def mlp_encode(P, X):
    pooled = jax.nn.gelu(jax.nn.gelu(X @ P["w1"] + P["b1"]) @ P["w2"] + P["b2"])
    return pooled @ P["proj"], pooled


def normalize(z):
    return z / jnp.sqrt(jnp.sum(z * z, axis=-1, keepdims=True) + 1e-12)


class DualEncoder:
    """loss='pairs'  : symmetric InfoNCE over mini-batches of teacher-child pairs (original formulation)
       loss='teacher': child -> teacher softmax over all training teachers (teacher-aware formulation)
       lam          : weight of the auxiliary behavioural-prediction loss (multi-task when lam > 0)"""

    def __init__(self, arch="tf", loss="teacher", lam=0.0, tau=0.1, lr=1e-3, epochs=300, batch=128, seed=0):
        self.arch, self.loss, self.lam, self.tau, self.lr, self.epochs, self.batch, self.seed = arch, loss, lam, tau, lr, epochs, batch, seed
        self.enc = tf_encode if arch == "tf" else mlp_encode
        self.init = _init_tf if arch == "tf" else _init_mlp

    def fit(self, Xc, Xt, tid, Y=None, train_teachers=None, ckpt=None):
        key = jax.random.PRNGKey(self.seed); k1, k2, k3 = jax.random.split(key, 3)
        ny = 0 if Y is None else Y.shape[1]
        params = dict(c=self.init(k1, Xc.shape[1]), t=self.init(k2, Xt.shape[1]),
                      head=dict(w=jax.random.normal(k3, (D_MODEL, max(ny, 1))) * 0.1, b=jnp.zeros(max(ny, 1))))
        Xc, Xt = jnp.asarray(Xc, jnp.float32), jnp.asarray(Xt, jnp.float32)
        tid = jnp.asarray(tid); Y = jnp.zeros((Xc.shape[0], 1)) if Y is None else jnp.asarray(Y, jnp.float32)
        tt = jnp.asarray(np.unique(np.asarray(tid)) if train_teachers is None else train_teachers)
        enc, tau, lam, lossname = self.enc, self.tau, self.lam, self.loss

        def loss_fn(P, idx):
            zc, hc = enc(P["c"], Xc[idx]); zc = normalize(zc)
            if lossname == "pairs":
                zt = normalize(enc(P["t"], Xt[tid[idx]])[0])
                lg = zc @ zt.T / tau; lab = jnp.arange(idx.shape[0])
                l = 0.5 * (-jnp.mean(jax.nn.log_softmax(lg, 1)[lab, lab]) - jnp.mean(jax.nn.log_softmax(lg, 0)[lab, lab]))
            else:
                zt = normalize(enc(P["t"], Xt[tt])[0])
                lg = zc @ zt.T / tau
                pos = (tid[idx][:, None] == tt[None, :])
                l = -jnp.mean(jnp.sum(jax.nn.log_softmax(lg, 1) * pos, 1))
            if lam > 0:
                pred = hc @ P["head"]["w"] + P["head"]["b"]
                l = l + lam * jnp.mean((pred - Y[idx]) ** 2)
            return l

        # Adam
        m = jax.tree_util.tree_map(jnp.zeros_like, params); v = jax.tree_util.tree_map(jnp.zeros_like, params)
        lr, b1, b2 = self.lr, 0.9, 0.999

        @jax.jit
        def step(P, m, v, t, idx):
            l, g = jax.value_and_grad(loss_fn)(P, idx)
            m = jax.tree_util.tree_map(lambda a, b: b1 * a + (1 - b1) * b, m, g)
            v = jax.tree_util.tree_map(lambda a, b: b2 * a + (1 - b2) * b * b, v, g)
            P = jax.tree_util.tree_map(lambda p, a, b: p - lr * (a / (1 - b1 ** t)) / (jnp.sqrt(b / (1 - b2 ** t)) + 1e-8), P, m, v)
            return P, m, v, l

        rng = np.random.default_rng(self.seed); n = Xc.shape[0]; t = 0; self.losses = []; ep0 = 0
        if ckpt and os.path.exists(ckpt):
            st = pickle.load(open(ckpt, "rb"))
            params, m, v, t, self.losses, ep0 = st["P"], st["m"], st["v"], st["t"], st["losses"], st["ep"]
            rng = st["rng"]
        for ep in range(ep0, self.epochs):
            perm = rng.permutation(n); el = []
            for s in range(0, n, self.batch):
                idx = perm[s:s + self.batch]
                if len(idx) < 8:
                    continue
                t += 1
                params, m, v, l = step(params, m, v, t, jnp.asarray(idx))
                el.append(float(l))
            self.losses.append(float(np.mean(el)))
            if ckpt and (ep + 1) % 25 == 0:
                pickle.dump(dict(P=jax.device_get(params), m=jax.device_get(m), v=jax.device_get(v), t=t,
                                 losses=self.losses, ep=ep + 1, rng=rng), open(ckpt, "wb"))
        self.P = params
        return self

    def embed_children(self, Xc):
        z, h = self.enc(self.P["c"], jnp.asarray(Xc, jnp.float32))
        return np.asarray(normalize(z)), np.asarray(h)

    def embed_teachers(self, Xt):
        return np.asarray(normalize(self.enc(self.P["t"], jnp.asarray(Xt, jnp.float32))[0]))
