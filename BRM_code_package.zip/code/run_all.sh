#!/bin/sh
# Run every analysis in order. Set PROW_DATA to the data file (the synthetic file by default).
export PROW_DATA=${PROW_DATA:-synthetic_prow.xlsx}
[ -f "$PROW_DATA" ] || python3 synth.py "$PROW_DATA"
mkdir -p cache
python3 classical.py
python3 stage2.py
for job in fast sweep extra fixcenter tf_rep tf_child tf_teacher tf_raw; do
  [ -f res_$job.json ] || python3 experiments.py $job
done
python3 summarize.py
