"""Data preparation for the ProW Cyprus Wave 1 (T1) teacher-child analyses."""
import os, numpy as np, pandas as pd, warnings
warnings.filterwarnings("ignore")
F12 = os.environ.get("PROW_DATA", "ProW_Reporting_data__T1-T2_.xlsx")
TEACHER_SCALES = ("TSWQ", "PERMA", "TSES-short", "TSSES", "JobSat", "MBI", "PCS")
CHILD_SCALES = ("SDQ", "ASBI", "CBRS")
SDQ_PROSOCIAL = [1, 4, 9, 17, 20]
SDQ_REVERSED = [7, 11, 14, 21, 25]
ASBI_REVERSED = [4, 13, 24]
CBRS_REVERSED = [5, 6]


def _clean(df):
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def child_scores(c):
    """Standard scale scores from raw item responses."""
    sdq = {i: c[f"SDQ_{i}"] - 1 for i in range(1, 26)}           # 0-2
    for i in SDQ_REVERSED:
        sdq[i] = 2 - sdq[i]
    diff = [i for i in range(1, 26) if i not in SDQ_PROSOCIAL]
    out = pd.DataFrame(index=c.index)
    out["SDQ_TD"] = sum(sdq[i] for i in diff)                         # total difficulties 0-40
    out["SDQ_PRO"] = sum(sdq[i] for i in SDQ_PROSOCIAL)               # prosocial 0-10
    a = pd.concat([4 - c[f"ASBI_{i}"] if i in ASBI_REVERSED else c[f"ASBI_{i}"] for i in range(1, 26)], axis=1)
    out["ASBI"] = a.mean(1)
    b = pd.concat([6 - c[f"CBRS_{i}"] if i in CBRS_REVERSED else c[f"CBRS_{i}"] for i in range(1, 33)], axis=1)
    out["CBRS"] = b.mean(1)
    return out


def load_t1():
    c = _clean(pd.read_excel(F12, sheet_name="T1_Children"))
    t = _clean(pd.read_excel(F12, sheet_name="T1_Teachers"))
    citems = [x for x in c.columns if x.split("_")[0] in CHILD_SCALES]
    titems = [x for x in t.columns if x.split("_")[0] in TEACHER_SCALES]
    c = c[c["Teacher ID"].isin(t["Teacher_ID"])].reset_index(drop=True)          # 757 matched children
    teachers = sorted(c["Teacher ID"].unique())
    t = t.set_index("Teacher_ID").loc[teachers].reset_index()
    tid = c["Teacher ID"].map({k: i for i, k in enumerate(teachers)}).values
    Xc_raw = c[citems].astype(float).values
    Xt_raw = t[titems].astype(float).values
    return dict(children=c, teachers=t, citems=citems, titems=titems, tid=tid,
                Xc_raw=Xc_raw, Xt_raw=Xt_raw, scores=child_scores(c), n_teachers=len(teachers))


def zscore(X, ref=None):
    ref = X if ref is None else ref
    mu, sd = ref.mean(0), ref.std(0)
    sd[sd == 0] = 1
    return (X - mu) / sd


def center_within(X, g):
    Xc = X.copy()
    for k in np.unique(g):
        Xc[g == k] -= X[g == k].mean(0)
    return Xc


def icc1(y, g):
    """ICC(1) from one-way random-effects ANOVA with unequal group sizes."""
    y = np.asarray(y, float); groups = np.unique(g)
    n = len(y); k = len(groups)
    ni = np.array([np.sum(g == j) for j in groups])
    means = np.array([y[g == j].mean() for j in groups])
    ssb = np.sum(ni * (means - y.mean()) ** 2); ssw = sum(np.sum((y[g == j] - y[g == j].mean()) ** 2) for j in groups)
    msb, msw = ssb / (k - 1), ssw / (n - k)
    n0 = (n - np.sum(ni ** 2) / n) / (k - 1)
    return (msb - msw) / (msb + (n0 - 1) * msw)


def center_within_train(X, g, train_idx):
    """Center each teacher's rows by the mean of that teacher's TRAINING rows only (no test leakage)."""
    Xc = X.copy(); tr = np.zeros(len(g), bool); tr[train_idx] = True
    for k in np.unique(g):
        rows = g == k; ref = rows & tr
        if ref.any():
            Xc[rows] -= X[ref].mean(0)
    return Xc
