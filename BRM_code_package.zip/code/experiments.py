"""Model experiments. Usage: python experiments.py <job>

Jobs: fast (CCA and perceptron), sweep and extra (multi-task weights), fixcenter (within-teacher centering),
tf_rep (original in-sample design), tf_child, tf_teacher, tf_raw (Transformer runs).
Results are written to res_<job>.json; finished folds are cached in cache/ so interrupted jobs can be restarted."""
import sys, json, time, os, numpy as np
from sklearn.model_selection import StratifiedKFold, GroupKFold
from sklearn.cross_decomposition import CCA
from sklearn.linear_model import RidgeCV
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from data import *
from models import DualEncoder

D = load_t1(); tid = D["tid"]; T = D["n_teachers"]; n = len(tid)
Xc_all = zscore(D["Xc_raw"]); Xt = zscore(D["Xt_raw"])
S = D["scores"]; Y_all = zscore(S[["SDQ_TD", "ASBI", "CBRS"]].values)
# raw item sums, as used for the behavioural targets in the original multi-task model (not standardized)
_c = D["children"]
Y_raw = np.column_stack([_c[[f"SDQ_{i}" for i in range(1, 26)]].sum(1), _c[[f"ASBI_{i}" for i in range(1, 26)]].sum(1),
                         _c[[f"CBRS_{i}" for i in range(1, 33)]].sum(1)]).astype(float)
PHEN = np.load("phenotype_labels.npy")


def teacher_rank_metrics(Zc, Zt, true_t, cand):
    """Rank candidate teachers (rows of Zt indexed by cand) for each child."""
    sims = Zc @ Zt[cand].T
    order = np.argsort(-sims, 1); ranked = np.asarray(cand)[order]
    hit = ranked == true_t[:, None]
    return {f"top{k}": float(hit[:, :k].any(1).mean()) for k in (1, 3, 5)}


def pair_metrics(Zc, Zt, tid_):
    """Original metric: each pair's teacher embedding ranks all children."""
    sims = Zt[tid_] @ Zc.T
    rank = (sims > sims[np.arange(len(tid_)), np.arange(len(tid_))][:, None]).sum(1)
    return {f"top{k}": float((rank < k).mean()) for k in (1, 5, 10)}


def behaviour_metrics(Htr, Ytr, Hte, Yte, lab_te):
    r = RidgeCV(alphas=np.logspace(-3, 3, 13)).fit(Htr, Ytr)
    P = r.predict(Hte)
    r2 = 1 - ((Yte - P) ** 2).sum(0) / ((Yte - Yte.mean(0)) ** 2).sum(0)
    km = KMeans(4, n_init=20, random_state=0).fit(Hte)
    return dict(r2=[float(x) for x in r2], r2_mean=float(r2.mean()),
                ari=float(adjusted_rand_score(lab_te, km.labels_)), silhouette=float(silhouette_score(Hte, lab_te)))


def cca_embed(Xc_tr, Xt_pairs_tr, Xc_te, Xt_cand, k=10):
    cca = CCA(n_components=k, max_iter=2000).fit(Xc_tr, Xt_pairs_tr)
    zc, _ = cca.transform(Xc_te, Xt_pairs_tr[:2])
    _, zt = cca.transform(Xc_te[:2], Xt_cand)
    nz = lambda z: z / (np.linalg.norm(z, axis=1, keepdims=True) + 1e-8)
    return nz(zc), nz(zt)


def child_holdout(arch, epochs, centered=False, lam=0.0, folds=5, seed=0, raw_targets=False):
    skf = StratifiedKFold(folds, shuffle=True, random_state=seed)
    out = []
    tag = f"cache/child_{arch}_{epochs}_{int(centered)}_{lam}_{int(raw_targets)}" + ("_trc" if centered else "")
    for f, (tr, te) in enumerate(skf.split(Xc_all, tid)):
        Xc = center_within_train(Xc_all, tid, tr) if centered else Xc_all
        if os.path.exists(f"{tag}_f{f}.json"):
            out.append(json.load(open(f"{tag}_f{f}.json"))); continue
        t0 = time.time()
        if arch == "cca":
            Zc_te, Zt = cca_embed(Xc[tr], Xt[tid[tr]], Xc[te], Xt)
            rec = dict(fold=f, retrieval=teacher_rank_metrics(Zc_te, Zt, tid[te], np.arange(T)))
        else:
            m = DualEncoder(arch=arch, loss="teacher", lam=lam, epochs=epochs, seed=seed + f).fit(
                Xc[tr], Xt, tid[tr], Y=(Y_raw if raw_targets else Y_all)[tr] if lam > 0 else None, train_teachers=np.arange(T))
            Zc_te, Hte = m.embed_children(Xc[te]); _, Htr = m.embed_children(Xc[tr]); Zt = m.embed_teachers(Xt)
            rec = dict(fold=f, retrieval=teacher_rank_metrics(Zc_te, Zt, tid[te], np.arange(T)),
                       behaviour=behaviour_metrics(Htr, Y_all[tr], Hte, Y_all[te], PHEN[te]), final_loss=m.losses[-1])
        rec["seconds"] = time.time() - t0
        json.dump(rec, open(f"{tag}_f{f}.json", "w"))
        out.append(rec); print(arch, "centered" if centered else "", lam, rec, flush=True)
    return out


def teacher_holdout(arch, epochs, folds=5, seed=0):
    gkf = GroupKFold(folds); out = []; tag = f"cache/teacher_{arch}_{epochs}"
    for f, (tr, te) in enumerate(gkf.split(Xc_all, tid, groups=tid)):
        if os.path.exists(f"{tag}_f{f}.json"):
            out.append(json.load(open(f"{tag}_f{f}.json"))); continue
        t0 = time.time(); test_t = np.unique(tid[te]); train_t = np.unique(tid[tr])
        if arch == "cca":
            Zc_te, Zt_c = cca_embed(Xc_all[tr], Xt[tid[tr]], Xc_all[te], Xt[test_t])
            Zt = np.zeros((T, Zt_c.shape[1])); Zt[test_t] = Zt_c
        else:
            m = DualEncoder(arch=arch, loss="teacher", epochs=epochs, seed=seed + f).fit(
                Xc_all[tr], Xt, tid[tr], train_teachers=train_t)
            Zc_te, _ = m.embed_children(Xc_all[te]); Zt = m.embed_teachers(Xt)
        rec = dict(fold=f, n_test_teachers=int(len(test_t)), chance_top1=float(1 / len(test_t)),
                   retrieval=teacher_rank_metrics(Zc_te, Zt, tid[te], test_t), seconds=time.time() - t0)
        json.dump(rec, open(f"{tag}_f{f}.json", "w"))
        out.append(rec); print(arch, "teacher-holdout", rec, flush=True)
    return out


def rater_centered():
    from sklearn.linear_model import LogisticRegression
    skf = StratifiedKFold(5, shuffle=True, random_state=0); a1, a5 = [], []
    for tr, te in skf.split(Xc_all, tid):
        X = center_within_train(Xc_all, tid, tr)
        clf = LogisticRegression(C=0.1, max_iter=3000).fit(X[tr], tid[tr]); P = clf.predict_proba(X[te]); cls = clf.classes_
        r = np.argsort(-P, 1); a1.append(np.mean(cls[r[:, 0]] == tid[te])); a5.append(np.mean([tid[te][i] in cls[r[i, :5]] for i in range(len(te))]))
    return dict(top1=float(np.mean(a1)), top5=float(np.mean(a5)))


def replication(epochs=150):
    """Original formulation and evaluation: pair InfoNCE, in-sample retrieval of children for each pair's teacher."""
    m = DualEncoder(arch="tf", loss="pairs", epochs=epochs, seed=0).fit(Xc_all, Xt, tid, ckpt="cache/rep.pkl")
    Zc, H = m.embed_children(Xc_all); Zt = m.embed_teachers(Xt)
    res = dict(pair_metric_in_sample=pair_metrics(Zc, Zt, tid),
               teacher_metric_in_sample=teacher_rank_metrics(Zc, Zt, tid, np.arange(T)), losses=m.losses[::10])
    # how many of the top-10 children retrieved for a teacher are that teacher's own children?
    sims = Zt @ Zc.T; top10 = np.argsort(-sims, 1)[:, :10]
    res["share_top10_same_classroom"] = float(np.mean([np.mean(tid[top10[j]] == j) for j in range(T)]))
    # behavioural content of the contrastive child embedding (in-sample probe, as in the original analysis)
    res["behaviour_in_sample"] = behaviour_metrics(H, Y_all, H, Y_all, PHEN)
    return res


if __name__ == "__main__":
    name = sys.argv[1]; R = {}
    if name == "fast":          # MLP + CCA conditions
        R["cca_child"] = child_holdout("cca", 0)
        R["cca_teacher"] = teacher_holdout("cca", 0)
        R["mlp_child"] = child_holdout("mlp", 300)
        R["mlp_child_centered"] = child_holdout("mlp", 300, centered=True)
        R["mlp_teacher"] = teacher_holdout("mlp", 300)
    elif name == "sweep":       # multi-task trade-off with MLP encoders
        for lam in [0.0, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]:
            R[f"lam_{lam}"] = child_holdout("mlp", 300, lam=lam)
    elif name == "fixcenter":
        R["mlp_child_centered_train"] = child_holdout("mlp", 300, centered=True)
        R["rater_centered_train"] = rater_centered()
    elif name == "tf_rep":
        R["replication"] = replication(150)
    elif name == "tf_child":
        R["tf_child"] = child_holdout("tf", 60)
    elif name == "tf_teacher":
        R["tf_teacher"] = teacher_holdout("tf", 60)
    elif name == "extra":
        for lam in [30.0, 100.0]:
            R[f"lam_{lam}"] = child_holdout("mlp", 300, lam=lam)
        R["raw_targets_lam1"] = child_holdout("mlp", 300, lam=1.0, raw_targets=True)
    elif name == "tf_raw":
        R["tf_raw_targets_lam1"] = child_holdout("tf", 60, lam=1.0, raw_targets=True)
    elif name == "tf_std":
        R["tf_std_lam1"] = child_holdout("tf", 100, lam=1.0)
    elif name == "tf_multitask":
        R["tf_lam_0"] = child_holdout("tf", 100, lam=0.0, folds=5)
    json.dump(R, open(f"res_{name}.json", "w"), indent=1)
    print("DONE", name)
