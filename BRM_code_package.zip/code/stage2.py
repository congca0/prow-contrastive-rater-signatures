import numpy as np, pandas as pd, json
from scipy.stats import spearmanr
from data import *
D = load_t1(); tid = D["tid"]; T = D["n_teachers"]; lab = np.load("phenotype_labels.npy")
# label phenotypes by mean CBRS (highest adaptive = 0 ... highest risk = 3)
S = D["scores"]; order = np.argsort(-np.array([S["CBRS"][lab == k].mean() for k in range(4)]))
relab = np.zeros_like(lab); [relab.__setitem__(lab == order[r], r) for r in range(4)]
names = ["High Adaptive Functioning", "Moderate Adaptive Functioning", "Behavioral Vulnerability", "High Behavioral Risk"]
prof = pd.DataFrame({"n": np.bincount(relab)}, index=names)
for c in S: prof[c] = [S[c][relab == r].mean() for r in range(4)]
res = {"phenotype_profiles": prof.round(2).reset_index().to_dict("records")}
np.save("phenotype_labels_ordered.npy", relab)
# classroom composition (teachers with >= 5 children, as classroom proportions are unstable otherwise)
ni = np.bincount(tid); keep = np.where(ni >= 5)[0]
comp = np.array([[np.mean(relab[tid == t] == r) for r in range(4)] for t in keep])
Xt = D["Xt_raw"][keep]; items = D["titems"]
scales = {}
for s in ("TSWQ", "PERMA", "TSES-short", "TSSES", "JobSat", "MBI", "PCS"):
    cols = [j for j, c in enumerate(items) if c.split("_")[0] == s]
    scales[s] = Xt[:, cols].mean(1)
def bh(p):
    p = np.asarray(p); o = np.argsort(p); m = len(p)
    q = p[o] * m / np.arange(1, m + 1); q = np.minimum.accumulate(q[::-1])[::-1]
    out = np.empty(m); out[o] = np.minimum(q, 1); return out
def corr_table(feats):
    rows = []
    for name, x in feats.items():
        for r in range(4):
            rho, p = spearmanr(x, comp[:, r]); rows.append((name, names[r], rho, p))
    df = pd.DataFrame(rows, columns=["feature", "phenotype", "rho", "p"])
    df["q_fdr"] = bh(df.p.values)
    return df.sort_values("p")
sc = corr_table(scales); it = corr_table({c: Xt[:, j] for j, c in enumerate(items)})
res["n_classrooms"] = int(len(keep))
res["scale_level_top"] = sc.head(5).round(4).to_dict("records")
res["scale_level_n_tests"] = int(len(sc)); res["scale_level_q_min"] = float(sc.q_fdr.min())
res["item_level_top"] = it.head(5).round(4).to_dict("records")
res["item_level_n_tests"] = int(len(it)); res["item_level_q_min"] = float(it.q_fdr.min())
res["item_level_n_q_lt_05"] = int((it.q_fdr < .05).sum())
# external (temporal) validation: do T1 phenotypes predict T2 scale scores of the same children?
c2 = pd.read_excel(F12, sheet_name="T2_Children"); c2.columns = [str(c).strip() for c in c2.columns]
S2 = child_scores(c2); S2["Child ID"] = c2["Child ID"].values
c1 = D["children"][["Child ID"]].copy(); c1["phen"] = relab
for c in S: c1[c + "_T1"] = S[c].values
m = c1.merge(S2, on="Child ID")
from scipy.stats import f_oneway
val = {}
for c in ["SDQ_TD", "SDQ_PRO", "ASBI", "CBRS"]:
    y = m[c].values; g = m["phen"].values
    F, p = f_oneway(*[y[g == r] for r in range(4)])
    ss_b = sum(np.sum(g == r) * (y[g == r].mean() - y.mean()) ** 2 for r in range(4)); r2 = ss_b / np.sum((y - y.mean()) ** 2)
    val[c] = dict(n=int(len(y)), r2=float(r2), F=float(F), p=float(p))
res["t2_validation"] = val
json.dump(res, open("stage2.json", "w"), indent=1, default=float)
print(json.dumps(res, indent=1, default=float))
