"""Create a synthetic dataset with the structure of the ProW Wave 1/Wave 2 files.

The synthetic data contain no real participants. Child ratings are generated
with a child-level behavioral factor, a classroom effect, and rater effects
(level, spread and item-specific biases), so the analyses behave
qualitatively like they do on the real data.

    python synth.py synthetic_prow.xlsx
    PROW_DATA=synthetic_prow.xlsx python classical.py
"""
import sys
import numpy as np
import pandas as pd

rng = np.random.default_rng(2024)
N_TEACHERS = 63
sizes = np.clip(rng.poisson(12, N_TEACHERS), 1, 24)
teacher_ids = 200101 + np.arange(N_TEACHERS)

TEACHER_SCALES = [("TSWQ", 8, 1, 4), ("PERMA", 23, 0, 10), ("TSES-short", 12, 1, 9), ("TSSES", 28, 1, 9),
                  ("JobSat", 24, 1, 6), ("MBI", 22, 0, 6), ("PCS", 22, 1, 5)]
CHILD_SCALES = [("SDQ", 25, 3), ("ASBI", 25, 3), ("CBRS", 32, 5)]
SDQ_POSITIVE = {1, 4, 7, 9, 11, 14, 17, 20, 21, 25}
ASBI_NEGATIVE = {4, 13, 24}
CBRS_NEGATIVE = {5, 6}


def ordinal(latent, k, rng):
    cuts = np.quantile(latent, np.linspace(0, 1, k + 1)[1:-1]) + rng.normal(0, 0.1, k - 1)
    return 1 + np.searchsorted(np.sort(cuts), latent)


# teachers
wellbeing = rng.normal(0, 1, N_TEACHERS)
tcols = {"Group_ID": rng.integers(1, 3, N_TEACHERS), "Preschool_ID": (np.arange(N_TEACHERS) // 4) + 1,
         "Type": 1, "Loc": rng.integers(1, 3, N_TEACHERS), "Teacher_ID": teacher_ids}
for name, k, lo, hi in TEACHER_SCALES:
    sign = -1 if name == "MBI" else 1
    for j in range(1, k + 1):
        z = 0.7 * sign * wellbeing + rng.normal(0, 0.7, N_TEACHERS)
        tcols[f"{name}_{j}"] = np.clip(np.round((hi + lo) / 2 + z * (hi - lo) / 4), lo, hi).astype(int)
teachers = pd.DataFrame(tcols)

# children
tid = np.repeat(np.arange(N_TEACHERS), sizes); n = len(tid)
ability = rng.normal(0, 1, n)                                  # child adaptive functioning
classroom = rng.normal(0, 0.35, N_TEACHERS) + 0.15 * wellbeing  # weak link to teacher wellbeing
level = rng.normal(0, 0.45, N_TEACHERS)                        # rater leniency
spread = np.exp(rng.normal(0, 0.25, N_TEACHERS))               # rater use of the scale
ccols = {"Group_ID": tcols["Group_ID"][tid], "School ID": tcols["Preschool_ID"][tid], "Type": 1,
         "Location": tcols["Loc"][tid], "Child ID": 300001 + np.arange(n), "Teacher ID": teacher_ids[tid],
         "1. Gender": rng.integers(1, 3, n)}
for name, k, cats in CHILD_SCALES:
    for j in range(1, k + 1):
        positive = (name == "SDQ" and j in SDQ_POSITIVE) or (name == "ASBI" and j not in ASBI_NEGATIVE) or \
                   (name == "CBRS" and j not in CBRS_NEGATIVE)
        load = rng.uniform(0.5, 1.0) * (1 if positive else -1)
        bias = rng.normal(0, 0.35, N_TEACHERS)                 # item-specific rater bias
        latent = spread[tid] * (load * (ability + classroom[tid]) + level[tid] + bias[tid]) + rng.normal(0, 0.6, n)
        ccols[f"{name}_{j}"] = ordinal(latent, cats, rng)
children = pd.DataFrame(ccols)
# a few children whose teacher record is missing, as in the real data
children.loc[rng.choice(n, 5, replace=False), "Teacher ID"] = 209999

# wave 2: same children, behavior partly stable
t2 = children.copy()
ability2 = 0.75 * ability + rng.normal(0, 0.66, n)
for name, k, cats in CHILD_SCALES:
    for j in range(1, k + 1):
        col = f"{name}_{j}"
        r = np.corrcoef(children[col], ability)[0, 1]
        latent = np.sign(r) * ability2 + spread[tid] * (level[tid]) + rng.normal(0, 0.8, n)
        t2[col] = ordinal(latent, cats, rng)
t2 = t2.sample(frac=0.88, random_state=1)

out = sys.argv[1] if len(sys.argv) > 1 else "synthetic_prow.xlsx"
with pd.ExcelWriter(out) as w:
    children.to_excel(w, sheet_name="T1_Children", index=False)
    teachers.to_excel(w, sheet_name="T1_Teachers", index=False)
    t2.to_excel(w, sheet_name="T2_Children", index=False)
print(f"wrote {out}: {len(children)} children, {len(teachers)} teachers")
