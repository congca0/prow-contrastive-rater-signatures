import numpy as np, pandas as pd, json
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.cross_decomposition import CCA
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from data import *

D = load_t1(); tid = D["tid"]; T = D["n_teachers"]; n = len(tid)
ni = np.bincount(tid)
res = {"n_children": int(n), "n_teachers": int(T), "children_per_teacher": [float(ni.mean()), int(ni.min()), int(ni.max())]}
# ceilings for the original pair-level retrieval metric (query = teacher embedding, candidates = all children)
for k in (1, 5, 10):
    res[f"ceiling_top{k}"] = float(np.sum([m * min(k, m) / m for m in ni]) / n)
res["chance_top1_pairs"] = 1 / n
# ICC(1) of scale scores and items
S = D["scores"]
res["icc_scores"] = {c: float(icc1(S[c].values, tid)) for c in S}
Xc = zscore(D["Xc_raw"])
item_icc = np.array([icc1(Xc[:, j], tid) for j in range(Xc.shape[1])])
res["icc_items"] = dict(median=float(np.median(item_icc)), q1=float(np.quantile(item_icc, .25)), q3=float(np.quantile(item_icc, .75)),
                        min=float(item_icc.min()), max=float(item_icc.max()))
pc1 = PCA(1).fit_transform(Xc)[:, 0]
res["icc_pc1"] = float(icc1(pc1, tid))

# rater identification from child items: which teacher rated this child?
def rater_id(X, label):
    skf = StratifiedKFold(5, shuffle=True, random_state=0)
    # teachers with <5 children cannot be stratified; StratifiedKFold warns but works
    acc1, acc5 = [], []
    for tr, te in skf.split(X, tid):
        clf = LogisticRegression(C=0.1, max_iter=3000).fit(X[tr], tid[tr])
        P = clf.predict_proba(X[te]); cls = clf.classes_
        rank = np.argsort(-P, 1)
        acc1.append(np.mean(cls[rank[:, 0]] == tid[te]))
        acc5.append(np.mean([tid[te][i] in cls[rank[i, :5]] for i in range(len(te))]))
    return dict(top1=float(np.mean(acc1)), top5=float(np.mean(acc5)))
res["rater_id_items"] = rater_id(Xc, "items")
res["rater_id_scores"] = rater_id(zscore(S.values), "scores")
from data import center_within_train
def rater_id_centered(X):
    skf = StratifiedKFold(5, shuffle=True, random_state=0); a1 = []
    for tr, te in skf.split(X, tid):
        Xk = center_within_train(X, tid, tr)
        clf = LogisticRegression(C=0.1, max_iter=3000).fit(Xk[tr], tid[tr])
        a1.append(np.mean(clf.classes_[np.argmax(clf.predict_proba(Xk[te]), 1)] == tid[te]))
    return dict(top1=float(np.mean(a1)))
res["rater_id_items_centered"] = rater_id_centered(Xc)   # centering uses training children only
res["rater_id_chance_top1"] = float(np.max(ni) / n)   # majority-class rate

# phenotypes: PCA(10) + k-means(4), as in the original analysis
pca = PCA(10).fit(Xc); E = pca.transform(Xc)
res["pca_var_pc1"] = float(pca.explained_variance_ratio_[0]); res["pca_var_10"] = float(pca.explained_variance_ratio_.sum())
km = KMeans(4, n_init=50, random_state=0).fit(E); lab = km.labels_
res["phenotype_sizes"] = sorted(np.bincount(lab).tolist(), reverse=True)
# bootstrap stability (ARI between full-sample and bootstrap solutions on the full sample)
rng = np.random.default_rng(0); aris = []
for b in range(200):
    idx = rng.integers(0, n, n)
    kb = KMeans(4, n_init=10, random_state=b).fit(E[idx])
    aris.append(adjusted_rand_score(lab, kb.predict(E)))
res["phenotype_bootstrap_ari"] = [float(np.median(aris)), float(np.quantile(aris, .05)), float(np.quantile(aris, .95))]
# share of phenotype membership explained by classroom: ICC-like (Cramer's V between phenotype and teacher)
ct = pd.crosstab(lab, tid).values; chi2 = ((ct - ct.sum(1, keepdims=True) * ct.sum(0, keepdims=True) / n) ** 2 /
       (ct.sum(1, keepdims=True) * ct.sum(0, keepdims=True) / n)).sum()
res["cramers_v_phenotype_teacher"] = float(np.sqrt(chi2 / (n * (min(ct.shape) - 1))))
np.save("phenotype_labels.npy", lab)
json.dump(res, open("classical.json", "w"), indent=1)
print(json.dumps(res, indent=1))
