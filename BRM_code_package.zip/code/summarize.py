"""Summarize the saved results: prints tables 1-3 and draws Figures 1-2 into figures/."""
import json, os, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.chdir(os.path.dirname(os.path.abspath(__file__))); os.makedirs("figures", exist_ok=True)
L = lambda f: json.load(open(f)) if os.path.exists(f) else {}
C, S2 = L("classical.json"), L("stage2.json")
FAST, SW, EX = L("res_fast.json"), L("res_sweep.json"), L("res_extra.json")
REP = L("res_tf_rep.json").get("replication", {})
TFC = L("res_tf_child.json").get("tf_child", [])
TFT = L("res_tf_teacher.json").get("tf_teacher", [])
TFR = L("res_tf_raw.json").get("tf_raw_targets_lam1", [])
FIX = L("res_fixcenter.json")

pct = lambda x, d=1: f"{100 * x:.{d}f}%"
f2 = lambda x: f"{x:.2f}".replace("0.", ".", 1) if abs(x) < 1 else f"{x:.2f}"
f3 = lambda x: (f"{x:.3f}"[1:] if 0 <= x < 1 else f"{x:.3f}")


def m(folds, *keys):
    vals = []
    for fd in folds:
        v = fd
        for k in keys:
            v = v[k]
        vals.append(v)
    return float(np.mean(vals)), float(np.std(vals))


tok = {}
T = C["n_teachers"]
tok.update(N_CHILDREN=str(C["n_children"]), N_TEACHERS=str(T), MEAN_CLASS=f"{C['children_per_teacher'][0]:.1f}",
           MIN_CLASS=str(C["children_per_teacher"][1]), MAX_CLASS=str(C["children_per_teacher"][2]),
           CHANCE_UNIFORM=pct(1 / T), CHANCE_MAJORITY=pct(C["rater_id_chance_top1"]),
           CEIL_T1=pct(C["ceiling_top1"]), CEIL_T5=pct(C["ceiling_top5"]), CEIL_T10=pct(C["ceiling_top10"]),
           RATER_TOP1=pct(C["rater_id_items"]["top1"]), RATER_TOP5=pct(C["rater_id_items"]["top5"]),
           RATER_SCORES_TOP1=pct(C["rater_id_scores"]["top1"]), RATER_CENTERED_TOP1=pct(FIX["rater_centered_train"]["top1"]),
           ICC_ITEM_MED=f2(C["icc_items"]["median"]), ICC_ITEM_Q1=f2(C["icc_items"]["q1"]), ICC_ITEM_Q3=f2(C["icc_items"]["q3"]),
           PCA_PC1=pct(C["pca_var_pc1"]), PCA_10=pct(C["pca_var_10"]),
           BOOT_ARI=f2(C["phenotype_bootstrap_ari"][0]), BOOT_ARI_LO=f2(C["phenotype_bootstrap_ari"][1]),
           BOOT_ARI_HI=f2(C["phenotype_bootstrap_ari"][2]), CRAMERS_V=f2(C["cramers_v_phenotype_teacher"]))
icc = C["icc_scores"]
tok["ICC_SCORE_RANGE"] = f"{pct(min(icc.values()), 0)} and {pct(max(icc.values()), 0)}"
prof = S2["phenotype_profiles"]
for i, p in enumerate(prof):
    tok[f"PH_N{i}"] = str(p["n"])
t2 = S2["t2_validation"]
r2s = [v["r2"] for v in t2.values()]
tok["T2_R2_RANGE"] = f"{pct(min(r2s), 0)}–{pct(max(r2s), 0)}"; tok["T2_N"] = str(list(t2.values())[0]["n"])
tok["N_CLASSROOMS"] = str(S2["n_classrooms"])
sc = S2["scale_level_top"]
tok.update(PCS_RHO=f2(sc[0]["rho"]), PCS_P=f3(sc[0]["p"]), MBI_RHO=f2(sc[1]["rho"]), MBI_P=f3(sc[1]["p"]),
           SCALE_QMIN=f2(S2["scale_level_q_min"]), ITEM_QMIN=f2(S2["item_level_q_min"]),
           ITEM_RHO_MAX=f2(abs(S2["item_level_top"][0]["rho"])))

# replication
if REP:
    pm = REP["pair_metric_in_sample"]
    tok.update(REP_T1=pct(pm["top1"]), REP_T5=pct(pm["top5"]), REP_T10=pct(pm["top10"]),
               REP_TOP1_PCT_OF_CEIL=pct(pm["top1"] / C["ceiling_top1"], 0), REP_SHARE_SAME=pct(REP["share_top10_same_classroom"], 0),
               REP_TEACHER_T1=pct(REP["teacher_metric_in_sample"]["top1"]))
# held-out children
if FAST:
    tok["MLP_CHILD_T1"] = pct(m(FAST["mlp_child"], "retrieval", "top1")[0])
    tok["CCA_CHILD_T1"] = pct(m(FAST["cca_child"], "retrieval", "top1")[0])
    tok["MLP_CENTERED_T1"] = pct(m(FIX["mlp_child_centered_train"], "retrieval", "top1")[0])
    FAST["mlp_child_centered"] = FIX["mlp_child_centered_train"]
    tok["TH_MLP_TOP1"] = pct(m(FAST["mlp_teacher"], "retrieval", "top1")[0])
    tok["TH_CCA_TOP1"] = pct(m(FAST["cca_teacher"], "retrieval", "top1")[0])
    tok["TH_CHANCE"] = pct(m(FAST["cca_teacher"], "chance_top1")[0])
    tok["TH_N_TEST_TEACHERS"] = f"{m(FAST['cca_teacher'], 'n_test_teachers')[0]:.1f}"
if TFC:
    tok["TF_CHILD_T1"] = pct(m(TFC, "retrieval", "top1")[0]); tok["TF_R2"] = f2(m(TFC, "behaviour", "r2_mean")[0])
if TFT:
    tok["TH_TF_TOP1"] = pct(m(TFT, "retrieval", "top1")[0])
# sweep
lams = [0.0, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0, 30.0, 100.0]
SWALL = {**SW, **{k: v for k, v in EX.items() if k.startswith("lam_")}}
sweep = {l: SWALL[f"lam_{l}"] for l in lams if f"lam_{l}" in SWALL}
if sweep:
    tok["R2_LAM0"] = f2(m(sweep[0.0], "behaviour", "r2_mean")[0]); tok["R2_LAM1"] = f2(m(sweep[1.0], "behaviour", "r2_mean")[0])
    tok["ARI_LAM0"] = f2(m(sweep[0.0], "behaviour", "ari")[0]); tok["ARI_LAM1"] = f2(m(sweep[1.0], "behaviour", "ari")[0])
    tok["T1_LAM0"] = pct(m(sweep[0.0], "retrieval", "top1")[0]); tok["T1_LAM1"] = pct(m(sweep[1.0], "retrieval", "top1")[0])
    mid = [m(sweep[l], "retrieval", "top1")[0] for l in lams if 0.03 <= l <= 10 and l in sweep]
    tok["T1_SWEEP_MIN"] = pct(min(mid)); tok["T1_SWEEP_MAX"] = pct(max(mid))
    if 100.0 in sweep:
        tok["T1_LAM100"] = pct(m(sweep[100.0], "retrieval", "top1")[0])
if "raw_targets_lam1" in EX:
    tok["T1_RAW_MLP"] = pct(m(EX["raw_targets_lam1"], "retrieval", "top1")[0])
if TFR:
    tok["T1_RAW_TF"] = pct(m(TFR, "retrieval", "top1")[0])

# raw-target (original multi-task formulation) wording depends on whether matching collapsed
if "raw_targets_lam1" in EX:
    raw_mlp = m(EX["raw_targets_lam1"], "retrieval", "top1")[0]; base = m(sweep[0.0], "retrieval", "top1")[0]
    raw_tf = m(TFR, "retrieval", "top1")[0] if TFR else None
    tf_base = m(TFC, "retrieval", "top1")[0] if TFC else None
    tok["R2_RAW"] = f2(m(EX["raw_targets_lam1"], "behaviour", "r2_mean")[0])
    tf_part = (f" and from {pct(tf_base)} to {pct(raw_tf)} for the Transformer" if (raw_tf is not None and tf_base is not None) else "")
    collapse = raw_tf is not None and raw_tf < 0.10
    tok["RAW_SENTENCE"] = (f"With unstandardized raw item sums as targets and λ = 1, the setting of the original multi-task model, "
        f"matching of held-out children changed from {pct(base)} to {pct(raw_mlp)} for the perceptron{tf_part}. ")
    if collapse:
        tok["RAW_SENTENCE"] += ("The steep loss of matching reported for the original multi-task model therefore arose when an unscaled "
                                "auxiliary loss dominated training, rather than from a conflict between the two objectives.")
        tok["RAW_ABSTRACT"] = "Matching collapsed only when unstandardized targets dominated the loss. "
        tok["RAW_DISCUSSION"] = "The steep trade-off appeared only when an unscaled auxiliary loss overwhelmed the contrastive loss."
    else:
        tok["RAW_SENTENCE"] += ("Unscaled targets thus reduced matching somewhat but did not reproduce the near-complete loss of matching "
                                "reported for the original multi-task model, which may reflect implementation details that we could not reconstruct.")
        tok["RAW_ABSTRACT"] = ""
        tok["RAW_DISCUSSION"] = ("Unscaled targets reduced matching only moderately, and we could not reproduce the near-complete loss of "
                                 "matching reported for the original multi-task model.")

# ---------------- tables
names = ["High Adaptive Functioning", "Moderate Adaptive Functioning", "Behavioral Vulnerability", "High Behavioral Risk"]
t1 = ["| Phenotype | n | SDQ total difficulties | SDQ prosocial | ASBI | CBRS |", "|:--|--:|--:|--:|--:|--:|"]
for p in prof:
    t1.append(f"| {p['index']} | {p['n']} | {p['SDQ_TD']:.2f} | {p['SDQ_PRO']:.2f} | {p['ASBI']:.2f} | {p['CBRS']:.2f} |")
t1.append(f"| Wave 2 R² explained by baseline phenotype (n = {tok['T2_N']}) |  | {f2(t2['SDQ_TD']['r2'])} | {f2(t2['SDQ_PRO']['r2'])} | {f2(t2['ASBI']['r2'])} | {f2(t2['CBRS']['r2'])} |")
tok["TABLE1"] = "\n".join(t1)

ms = lambda folds, k: "{:.1f} ({:.1f})".format(*[100 * x for x in m(folds, "retrieval", k)]) if folds else "—"
t2r = ["| Design and model | Top-1 | Top-5 | Top-10 | Chance (Top-1) |", "|:--|--:|--:|--:|--:|"]
if REP:
    pm = REP["pair_metric_in_sample"]
    t2r.append(f"| (a) In-sample, pair ranking: Transformer, pair-level loss | {100*pm['top1']:.1f} | {100*pm['top5']:.1f} | {100*pm['top10']:.1f} | {100/C['n_children']:.2f} |")
t2r.append(f"| (a) In-sample, pair ranking: classroom-oracle ceiling | {100*C['ceiling_top1']:.1f} | {100*C['ceiling_top5']:.1f} | {100*C['ceiling_top10']:.1f} | — |")
t2r.append(f"| (b) Held-out children, teacher ranking: rater classifier (child items only) | {100*C['rater_id_items']['top1']:.1f} | {100*C['rater_id_items']['top5']:.1f} | — | {100/T:.1f} |")
for lab, key in [("CCA", "cca_child"), ("Perceptron, teacher-level loss", "mlp_child"), ("Perceptron, items centered within teacher", "mlp_child_centered")]:
    if FAST:
        t2r.append(f"| (b) Held-out children, teacher ranking: {lab} | {ms(FAST[key], 'top1')} | {ms(FAST[key], 'top5')} | — | {100/T:.1f} |")
if TFC:
    t2r.append(f"| (b) Held-out children, teacher ranking: Transformer, teacher-level loss | {ms(TFC, 'top1')} | {ms(TFC, 'top5')} | — | {100/T:.1f} |")
for lab, folds in [("CCA", FAST.get("cca_teacher", [])), ("Perceptron", FAST.get("mlp_teacher", [])), ("Transformer", TFT)]:
    if folds:
        t2r.append(f"| (c) Held-out teachers, teacher ranking: {lab} | {ms(folds, 'top1')} | {ms(folds, 'top5')} | — | {100*m(folds, 'chance_top1')[0]:.1f} |")
tok["TABLE2"] = "\n".join(t2r) + "\n\n*Note.* Values are percentages. For designs (b) and (c), means (SD) over five folds; in (c) each child is ranked against the teachers of its test fold only."

t3 = ["| λ | Top-1 | Top-5 | Probe R² | ARI with phenotypes | Silhouette |", "|--:|--:|--:|--:|--:|--:|"]
for l, folds in sweep.items():
    t3.append(f"| {l:g} | {ms(folds, 'top1')} | {ms(folds, 'top5')} | {m(folds, 'behaviour', 'r2_mean')[0]:.2f} | {m(folds, 'behaviour', 'ari')[0]:.2f} | {m(folds, 'behaviour', 'silhouette')[0]:.2f} |")
if "raw_targets_lam1" in EX:
    f_ = EX["raw_targets_lam1"]
    t3.append(f"| 1 (raw-sum targets) | {ms(f_, 'top1')} | {ms(f_, 'top5')} | {m(f_, 'behaviour', 'r2_mean')[0]:.2f} | {m(f_, 'behaviour', 'ari')[0]:.2f} | {m(f_, 'behaviour', 'silhouette')[0]:.2f} |")
tok["TABLE3"] = "\n".join(t3) + "\n\n*Note.* Top-1 and Top-5 are percentages of held-out children matched to their teacher among all teachers (means (SD) over five folds). Probe R² is the mean cross-validated R² for SDQ total difficulties, ASBI and CBRS."

# ---------------- figures
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
OI = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7", "#56B4E9"]
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.9), gridspec_kw=dict(width_ratios=[1, 1.5, 1.1]))
if REP:
    pm = REP["pair_metric_in_sample"]; ks = [1, 5, 10]
    ax[0].bar(range(3), [100 * pm[f"top{k}"] for k in ks], color=OI[0])
    for i, k in enumerate(ks):
        ax[0].hlines(100 * C[f"ceiling_top{k}"], i - .4, i + .4, colors="k", linestyles=":")
        ax[0].hlines(100 * k / C["n_children"], i - .4, i + .4, colors="grey", linestyles="--")
    ax[0].set_xticks(range(3)); ax[0].set_xticklabels(["Top-1", "Top-5", "Top-10"])
ax[0].set_ylabel("Accuracy (%)"); ax[0].set_title("(a) In-sample\n(original design)", fontsize=8.5, loc="left")
labs, vals, sds = ["Rater\nclassifier"], [100 * C["rater_id_items"]["top1"]], [0]
for lab, folds in [("CCA", FAST.get("cca_child")), ("Percep-\ntron", FAST.get("mlp_child")), ("Trans-\nformer", TFC or None), ("Percep-\ntron,\ncentered", FAST.get("mlp_child_centered"))]:
    if folds:
        mu, sd = m(folds, "retrieval", "top1"); labs.append(lab); vals.append(100 * mu); sds.append(100 * sd)
ax[1].bar(range(len(vals)), vals, yerr=sds, color=[OI[4]] + [OI[1]] * (len(vals) - 1), capsize=2)
ax[1].axhline(100 / T, color="grey", ls="--", lw=1)
ax[1].set_xticks(range(len(vals))); ax[1].set_xticklabels(labs, fontsize=7.5)
ax[1].set_title("(b) Held-out children,\nteachers seen in training", fontsize=8.5, loc="left")
labs, vals, sds, ch = [], [], [], []
for lab, folds in [("CCA", FAST.get("cca_teacher")), ("Percep-\ntron", FAST.get("mlp_teacher")), ("Trans-\nformer", TFT or None)]:
    if folds:
        mu, sd = m(folds, "retrieval", "top1"); labs.append(lab); vals.append(100 * mu); sds.append(100 * sd); ch.append(100 * m(folds, "chance_top1")[0])
if vals:
    ax[2].bar(range(len(vals)), vals, yerr=sds, color=OI[2], capsize=2); ax[2].axhline(np.mean(ch), color="grey", ls="--", lw=1)
    ax[2].set_xticks(range(len(vals))); ax[2].set_xticklabels(labs, fontsize=7.5)
ax[2].set_title("(c) Held-out teachers", fontsize=8.5, loc="left")
for a in ax[1:]:
    a.set_ylim(0, 60)
fig.tight_layout(); fig.savefig("figures/fig1.png", dpi=600); fig.savefig("figures/fig1.pdf"); plt.close(fig)

if sweep:
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.8))
    xs = list(sweep.keys()); xp = [0.01 if l == 0 else l for l in xs]
    for j, (key, lab) in enumerate([(("retrieval", "top1"), "Top-1 matching of held-out children (%)"), (("behaviour", "r2_mean"), "Probe R² (held-out children)")]):
        mu = [m(sweep[l], *key)[0] for l in xs]; sd = [m(sweep[l], *key)[1] for l in xs]
        sc_ = 100 if j == 0 else 1
        ax[j].errorbar(xp, [sc_ * v for v in mu], yerr=[sc_ * v for v in sd], marker="o", color=OI[0], capsize=2, label="Standardized targets")
        if "raw_targets_lam1" in EX:
            ax[j].errorbar([1.3], [sc_ * m(EX["raw_targets_lam1"], *key)[0]], yerr=[sc_ * m(EX["raw_targets_lam1"], *key)[1]],
                           marker="s", color=OI[3], ls="", capsize=2, label="Raw-sum targets, perceptron")
        if TFR:
            ax[j].errorbar([1.6], [sc_ * m(TFR, *key)[0]], yerr=[sc_ * m(TFR, *key)[1]], marker="^", color=OI[1], ls="", capsize=2,
                           label="Raw-sum targets, Transformer")
        ax[j].set_xscale("log"); ax[j].set_xticks([0.01, 0.1, 1, 10, 100]); ax[j].set_xticklabels(["0", "0.1", "1", "10", "100"])
        ax[j].set_xlabel("Weight of behavioral-prediction loss (λ)"); ax[j].set_ylabel(lab, fontsize=8)
    ax[0].axhline(100 / T, color="grey", ls="--", lw=1); ax[0].set_ylim(0, 45); ax[1].set_ylim(0, 1.02)
    ax[1].legend(fontsize=7, frameon=False, loc="lower right")
    fig.tight_layout(); fig.savefig("figures/fig2.png", dpi=600); fig.savefig("figures/fig2.pdf"); plt.close(fig)


for k in ("TABLE1", "TABLE2", "TABLE3"):
    if k in tok:
        print(tok[k], "\n")
