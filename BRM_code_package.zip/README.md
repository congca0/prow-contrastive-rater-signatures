# Rater signatures in contrastive learning on teacher-child questionnaires

Code for "Contrastive learning on linked teacher-child questionnaires recovers
rater signatures rather than teacher-child correspondence" (Cao, Kyriakides & Vrasidas).

The ProW participant data cannot be shared, so the code comes with synth.py,
which writes a synthetic file with the same sheets and columns as the original
(T1_Children, T1_Teachers, T2_Children). The synthetic children are rated by
synthetic teachers who differ in rating level and spread, so the analyses run
end to end and give qualitatively similar patterns. The numbers will not match
the paper.

Needs Python 3 with numpy, pandas, scipy, scikit-learn, matplotlib, openpyxl and jax.

    cd code
    sh run_all.sh

or step by step:

    python synth.py synthetic_prow.xlsx
    export PROW_DATA=synthetic_prow.xlsx
    python classical.py      # variance decomposition, rater identification, phenotypes
    python stage2.py         # phenotype profiles, Wave 2 validation, teacher-classroom correlations
    python experiments.py fast
    python experiments.py sweep
    ...
    python summarize.py      # tables and figures

To use the real data, set PROW_DATA to the path of ProW_Reporting_data__T1-T2_.xlsx.

The Transformer jobs (tf_*) take about 15 minutes each on one CPU core.
Finished folds are saved in code/cache/, so an interrupted job picks up where it stopped.

Files

    data.py         loading, scale scores, ICC, centering
    classical.py    ICCs, rater identification, PCA phenotypes, bootstrap stability
    stage2.py       phenotype profiles, Wave 2 validation, teacher-classroom correlations with FDR
    models.py       Transformer and perceptron dual encoders (JAX)
    experiments.py  evaluation designs, CCA baseline, multi-task weight sweep
    summarize.py    tables and figures from the saved results
    synth.py        synthetic data generator
